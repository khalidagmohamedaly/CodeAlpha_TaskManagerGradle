# CodeAlpha_TaskManagerGradle

**Stage DevOps — Tâche 3 : Java Application using Gradle**

Petite application Java (gestionnaire de tâches) avec build automatisé via Gradle, tests unitaires JUnit 5, mesure de couverture (JaCoCo) et intégration continue via GitHub Actions.

## 📁 Structure du projet

```
CodeAlpha_TaskManagerGradle/
├── src/
│   ├── main/java/com/codealpha/taskmanager/
│   │   ├── Task.java               # Modèle de données
│   │   ├── TaskManager.java        # Logique métier
│   │   ├── TaskNotFoundException.java
│   │   ├── Main.java                # Démo exécutable
│   │   └── ManualSmokeTest.java     # Smoke test sans dépendance (offline)
│   └── test/java/com/codealpha/taskmanager/
│       └── TaskManagerTest.java     # Suite de tests JUnit 5 (11 tests)
├── .github/workflows/ci.yml         # CI : build + tests + couverture
├── build.gradle
├── settings.gradle
└── gradle/wrapper/gradle-wrapper.properties
```

## ⚙️ Fonctionnalités de l'application

- Créer, lister, compléter et supprimer des tâches
- Priorités : `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`
- Tri automatique des tâches en attente par priorité décroissante
- Statistiques : répartition par priorité, taux de complétion

## 🚀 Build & exécution

### Avec Gradle installé sur ta machine
```bash
gradle build          # build complet (compile + tests + couverture)
gradle run            # lance la démo (classe Main)
gradle test           # exécute uniquement les tests JUnit 5
```

> **Note sur le wrapper Gradle (`gradlew`)** : le fichier binaire `gradle-wrapper.jar`
> n'est pas inclus dans ce repo (il doit être généré en local, pas de raison de le committer
> aveuglément). Si tu as Gradle installé (`sdk install gradle 8.11.1` via SDKMAN, ou `apt install gradle`),
> lance simplement `gradle wrapper` une fois dans le dossier du projet pour générer `gradlew`,
> `gradlew.bat` et le jar. Ensuite tu pourras utiliser `./gradlew build` comme d'habitude.
> La CI GitHub Actions, elle, n'a pas besoin du wrapper : elle utilise l'action officielle
> `gradle/actions/setup-gradle` qui provisionne Gradle directement.

### Sans Gradle (validation rapide avec javac/java uniquement)
```bash
mkdir -p out
javac -d out $(find src/main/java -name "*.java")
java -cp out com.codealpha.taskmanager.Main             # démo
java -cp out com.codealpha.taskmanager.ManualSmokeTest   # 8 tests manuels sans dépendance
```

## ✅ Tests

- **`TaskManagerTest.java`** (JUnit 5, 11 cas de test) : couvre l'ajout, la complétion,
  la suppression, le tri par priorité, la gestion des exceptions et le calcul du taux
  de complétion.
- **`ManualSmokeTest.java`** : version sans dépendance externe des cas de test les plus
  importants — utile pour valider rapidement la logique sans accès à Maven Central
  (déjà exécutée et validée : 8/8 tests passent ✅).

## 📊 Couverture de code

Le plugin JaCoCo génère un rapport HTML après `gradle build`, consultable dans
`build/reports/jacoco/test/html/index.html`.

## ✅ CI/CD

Le workflow `.github/workflows/ci.yml` exécute automatiquement `gradle build`
(compilation + tests + couverture) à chaque push ou pull request sur `main`,
et publie les résultats de tests en artefact téléchargeable.

## 📤 Pour la soumission CodeAlpha

```bash
git init
git add .
git commit -m "Initial commit - Task Manager Gradle App"
git branch -M main
git remote add origin https://github.com/<ton-username>/CodeAlpha_TaskManagerGradle.git
git push -u origin main
```
